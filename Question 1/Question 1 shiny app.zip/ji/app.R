library(shiny)
library(shinydashboard)
library(GEOquery)
library(dplyr)
library(ggpubr)
library(shinyFiles)
library(officer)
library(magrittr)
library(viridis)
library(DT)
library(cvTools)
library(ggplot2)
library(maps)
library(shinyjs)
library(ggrepel)
library(tidyverse)
library(patchwork)
library(devtools)
library(tsfeatures)
library(ggpubr)
library(janitor)
library(reshape2)
library(pROC)
library(plotROC)
library(leaflet)
library(GEOquery)
library(patchwork)
library(Biobase)
library(limma)
library(class)
library(tuneR)
library(e1071)
library(randomForest)
library(preprocessCore)
library(raster)
library(data.table)
library(MASS)
library(gridExtra)
library(caret)
library(RColorBrewer)
library(plotly)

# Load the datasets
Blood <- getGEO("GSE15296", GSEMatrix = TRUE, AnnotGPL = TRUE)[[1]]
Biopsy <- getGEO("GSE34437", GSEMatrix = TRUE, AnnotGPL = TRUE)[[1]]

eMat = exprs(Blood)
Blood$Outcome <- ifelse(grepl("AR", Blood$title), "Rejection", "Stable") 

eMat2 = exprs(Biopsy)
Biopsy$Outcome <- ifelse(grepl("AR", Biopsy$title), "Rejection", "Stable")

# Preprocessing (blood)
featureDatablood <- fData(Blood)
designblood <- model.matrix(~Outcome, data = pData(Blood))
fitblood <- lmFit(exprs(Blood), designblood)
fitblood <- eBayes(fitblood)

fit4blood <- topTable(fitblood, genelist = featureDatablood[, "Gene symbol"], n = Inf) |>
  rownames_to_column("row") |>
  filter(!is.na(ID)) |>
  filter(ID != "") |>
  group_by(ID) |>
  filter(P.Value == min(P.Value)) |>
  pull(row)

gset4blood <- Blood[fit4blood]

# Preprocessing (biopsy)
featureDatabiopsy <- fData(Biopsy)
designbiopsy <- model.matrix(~Outcome, data = pData(Biopsy))
fitbiopsy <- lmFit(exprs(Biopsy), designbiopsy)
fitbiopsy <- eBayes(fitbiopsy)

fit4biopsy <- topTable(fitbiopsy, genelist = featureDatabiopsy[, "Gene symbol"], n = Inf) |>
  rownames_to_column("row") |>
  filter(!is.na(ID)) |>
  filter(ID != "") |>
  group_by(ID) |>
  filter(P.Value == min(P.Value)) |>
  pull(row)

gset4biopsy <- Biopsy[fit4biopsy]

fvarLabels(Blood) <- make.names(fvarLabels(Blood))
# load series and platform data from GEO

# make proper column names to match toptable 
fvarLabels(Blood) <- make.names(fvarLabels(Blood))

# group names for all samples
gsms <- "undefined"
sml <- c()
for (i in 1:nchar(gsms)) { sml[i] <- substr(gsms,i,i) }

# log2 transform
ex <- exprs(Blood)
qx <- as.numeric(quantile(ex, c(0., 0.25, 0.5, 0.75, 0.99, 1.0), na.rm=T))
LogC <- (qx[5] > 100) ||
  (qx[6]-qx[1] > 50 && qx[2] > 0) ||
  (qx[2] > 0 && qx[2] < 1 && qx[4] > 1 && qx[4] < 2)
if (LogC) { ex[which(ex <= 0)] <- NaN
exprs(Blood) <- log2(ex) }


# Generate data
featureData <- fData(Blood)
cl <- factor(sample(c("YES", "NO"), 80, replace = TRUE))
fakeX <- matrix(rnorm(10000 * 80), nrow = 10000)
design <- model.matrix(~ cl + 0)
fakefit <- lmFit(fakeX, design)
cont.matrix <- makeContrasts(clYES - clNO, levels = design)
fakefit2 <- contrasts.fit(fakefit, cont.matrix)
fakefit2 <- eBayes(fakefit2)

featureData2 <- fData(Biopsy)
cl2 <- factor(sample(c("YES", "NO"), 80, replace = TRUE))
fakeX2 <- matrix(rnorm(10000 * 80), nrow = 10000)
design2 <- model.matrix(~ cl2 + 0)
fakefit4 <- lmFit(fakeX2, design2)
cont.matrix2 <- makeContrasts(cl2YES - cl2NO, levels = design2)
fakefit3 <- contrasts.fit(fakefit4, cont.matrix2)
fakefit3 <- eBayes(fakefit3)





fvarLabels(Biopsy) <- make.names(fvarLabels(Biopsy))
# load series and platform data from GEO

# make proper column names to match toptable 
fvarLabels(Biopsy) <- make.names(fvarLabels(Biopsy))

# group names for all samples
gsms2<- "undefined"
sml2<- c()
for (i in 1:nchar(gsms2)) { sml2[i] <- substr(gsms2,i,i) }

# log2 transform
ex2<- exprs(Biopsy)
qx2<- as.numeric(quantile(ex2, c(0., 0.25, 0.5, 0.75, 0.99, 1.0), na.rm=T))
LogC2<- (qx2[5] > 100) ||
  (qx2[6]-qx2[1] > 50 && qx2[2] > 0) ||
  (qx2[2] > 0 && qx2[2] < 1 && qx2[4] > 1 && qx2[4] < 2)
if (LogC2) { ex2[which(ex2 <= 0)] <- NaN
exprs(Biopsy) <- log2(ex2) }

#5.1 In-sample
gene4blood <- rownames(top4blood)[1:10]
gene4biopsy <- rownames(top4biopsy)[1:10]

X_gse4b = t(exprs(gset4blood)[ gene4blood, ])
y_gse4b = ifelse(grepl("AR", gset4blood$title), "Rejection", "Stable")
X_gse1b = t(exprs(gset4biopsy)[ gene4biopsy, ])
y_gse1b = ifelse(grepl("AR", gset4biopsy$title), "Stable","Rejection")

#In sample 

#Framework 1 (SVM)

set.seed(3888)

cvK = 5    # Number of CV folds
n_sim = 50 # Number of repeats

# SVM CV for (blood)

cv_accuracy_gse4b = numeric(n_sim)

for (i in 1:n_sim) {
  
  cvSets = cvFolds(nrow(X_gse4b), cvK)
  cv_accuracy_folds = numeric(cvK)
  
  for (j in 1:cvK) {
    test_id = cvSets$subsets[cvSets$which == j]
    X_train = X_gse4b[-test_id,]
    X_test = X_gse4b[test_id,]
    y_train = y_gse4b[-test_id]
    y_test = y_gse4b[test_id]
    
    svm_fit4blood = svm(x = X_train, y = as.factor(y_train))
    predictions = predict(svm_fit4blood, X_test)
    cv_accuracy_folds[j] = mean(y_test == predictions)
  }
  cv_accuracy_gse4b[i] = mean(cv_accuracy_folds)
}

# SVM CV for (biopsy)

cv_accuracy_gse1b = numeric(n_sim) # Vector to store averaged CV accuracies

for (i in 1:n_sim) {
  
  cvSets = cvFolds(nrow(X_gse1b), cvK) # Folds object for cross-validation
  cv_accuracy_folds = numeric(cvK) # Vector to store accuracy for each fold
  
  for (j in 1:cvK) {
    test_id = cvSets$subsets[cvSets$which == j]
    X_train = X_gse1b[-test_id,]
    X_test = X_gse1b[test_id,]
    y_train = y_gse1b[-test_id]
    y_test = y_gse1b[test_id]
    
    svm_fit4biopsy = svm(x = X_train, y = as.factor(y_train))
    predictions = predict(svm_fit4biopsy, X_test)
    cv_accuracy_folds[j] = mean(y_test == predictions)
  }
  cv_accuracy_gse1b[i] = mean(cv_accuracy_folds)
}

#5.2 Out-of-sample
X_gse4c = t(exprs(gset4blood))
y_gse4c = ifelse(grepl("AR", gset4blood$title), "Rejection", "Stable")
X_gse1c = t(exprs(gset4biopsy))
y_gse1c = ifelse(grepl("AR", gset4biopsy$title), "Rejection", "Stable")


set.seed(3888)

cvK = 5    # Number of CV folds
n_sim = 50 # Number of repeats

# SVM CV for (blood)

cv_accuracy_gse4c = numeric(n_sim)

for (i in 1:n_sim) {
  
  cvSets = cvFolds(nrow(X_gse4b), cvK)
  cv_accuracy_folds = numeric(cvK)
  
  for (j in 1:cvK) {
    test_id = cvSets$subsets[cvSets$which == j]
    X_train = X_gse4c[-test_id,]
    X_test = X_gse4c[test_id,]
    y_train = y_gse4c[-test_id]
    y_test = y_gse4c[test_id]
    
    design5 <- model.matrix(~y_train)
    fit5  <- lmFit(t(X_train), design5)
    fit5   <- eBayes(fit5)
    top5  <- topTable(fit5, n = 10)
    DE_genes <- rownames(top5)
    
    X_train = X_train[,DE_genes]
    X_test = X_test[,DE_genes]
    
    svm_fit4bloodout = svm(x = X_train, y = as.factor(y_train), kernel = "linear")
    predictions = predict(svm_fit4bloodout, X_test)
    cv_accuracy_folds[j] = mean(y_test == predictions)
  }
  cv_accuracy_gse4c[i] = mean(cv_accuracy_folds)
}

# SVM CV for (biopsy)

cv_accuracy_gse1c = numeric(n_sim) # Vector to store averaged CV accuracies

for (i in 1:n_sim) {
  
  cvSets = cvFolds(nrow(X_gse1c), cvK) # Folds object for cross-validation
  cv_accuracy_folds = numeric(cvK) # Vector to store accuracy for each fold
  
  for (j in 1:cvK) {
    test_id = cvSets$subsets[cvSets$which == j]
    X_train = X_gse1c[-test_id,]
    X_test = X_gse1c[test_id,]
    y_train = y_gse1c[-test_id]
    y_test = y_gse1c[test_id]
    
    design5 <- model.matrix(~y_train)
    fit5  <- lmFit(t(X_train), design5)
    fit5   <- eBayes(fit5)
    top5  <- topTable(fit5, n = 10)
    DE_genes <- rownames(top5)
    
    X_train = X_train[,DE_genes]
    X_test = X_test[,DE_genes]
    
    svm_fit4biopsyout = svm(x = X_train, y = as.factor(y_train), kernel = "linear")
    predictions = predict(svm_fit4biopsyout, X_test)
    cv_accuracy_folds[j] = mean(y_test == predictions)
  }
  cv_accuracy_gse1c[i] = mean(cv_accuracy_folds)
}
# Perform PCA on the data (blood)
pca_result <- prcomp(t(X_gse4c), center = TRUE, scale. = TRUE)
X_pca <- predict(pca_result, newdata = t(X_gse4c))
y_trimmed <- y_gse4c[1:nrow(X_pca)]
pca_df <- data.frame(PC1 = X_pca[, 1], PC2 = X_pca[, 2], y_gse4c = as.factor(y_trimmed))
svm_fit4bloodout <- svm(y_gse4c ~ ., data = pca_df, kernel = "linear")
x1 <- seq(min(pca_df$PC1), max(pca_df$PC1), length = 100)
x2 <- seq(min(pca_df$PC2), max(pca_df$PC2), length = 100)
grid <- expand.grid(PC1 = x1, PC2 = x2)
grid$predictions <- predict(svm_fit4bloodout, newdata = grid)

# Clean version (blood)
colors <- brewer.pal(length(levels(pca_df$y_gse4c)), "Set1")
result_df <- data.frame(PC1 = subset_df$PC1, PC2 = subset_df$PC2, True_Labels = subset_df$y_gse4c, Predicted_Labels = as.factor(predicted_labels))
result_df <- na.omit(result_df)
accuracy <- sum(result_df$True_Labels == result_df$Predicted_Labels) / nrow(result_df)

# Perform PCA on the data (biopsy)
pca_result1 <- prcomp(t(X_gse1c), center = TRUE, scale. = TRUE)
X_pca1 <- predict(pca_result1, newdata1 = t(X_gse1c))
y_trimmed1 <- y_gse1c[1:nrow(X_pca1)]
pca_df1 <- data.frame(PC1b = X_pca1[, 1], PC2b = X_pca1[, 2], y_gse1c = as.factor(y_trimmed1))
svm_fit4biopsyout <- svm(y_gse1c ~ ., data = pca_df1, kernel = "linear")
x1b <- seq(min(pca_df1$PC1b), max(pca_df1$PC1b), length = 100)
x2b <- seq(min(pca_df1$PC2b), max(pca_df1$PC2b), length = 100)
grid1 <- expand.grid(PC1b = x1b, PC2b = x2b)
predictions1 <- predict(svm_fit4biopsyout, newdata = grid1)
grid1$predictions1 <- predictions1


colors <- brewer.pal(length(levels(pca_df1$y_gse1c)), "Set1")
subset_df1 <- pca_df1[1:nrow(grid1), ]  # Add this line to define subset_df1
result_df1 <- data.frame(PC1b = subset_df1$PC1b, PC2b = subset_df1$PC2b, True_Labels1 = subset_df1$y_gse1c, predicted_labels1 = as.factor(predictions1))
result_df1 <- na.omit(result_df1)
accuracy1 <- sum(result_df1$True_Labels1 == result_df1$predicted_labels1) / nrow(result_df1)
# Define UI
ui <- navbarPage(
  "R-MEDiK App",
  # Apply CSS styling to the navbar
  tags$head(
    tags$style(
      HTML("
        .navbar-default {
          border-color: black;
          background-color: #1035AC;
          color: white;
        }
        
        .navbar-default .navbar-nav > li > a {
          color: white;
        }
      ")
    )
  ),
  
  # READ ME Tab
  tabPanel("Welcome",
           sidebarLayout(
             sidebarPanel(
               style = "background-color: #e6f0ff;", # Specify a lighter shade of blue using the hexadecimal color code
               p("Hello and welcome to the kidney sample tutorial app.  This app was designed to assist you in determining the sample types that are clinically used for kidney transplant patients. You can choose between two sample types in this app: blood and biopsy samples for comparison"),
               p("There are five steps that will help us determine which sample types are better predictors of Kidney transplant success, which include:"),
               h3(
                 HTML("<strong><span style='font-size: 14px; background-color: ;'>1. Data collection </span></strong>")
               ),
               h3(
                 HTML("<strong><span style='font-size: 14px; background-color: ;'>2. Data cleaning </span></strong>")
               ),
               h3(
                 HTML("<strong><span style='font-size: 14px; background-color: ;'>3. Data wrangling </span></strong>")
               ),
               h3(
                 HTML("<strong><span style='font-size: 14px; background-color: ;'>4. Exploratory Data Analysis </span></strong>")
               ),
               h3(
                 HTML("<strong><span style='font-size: 14px; background-color: ;'>5. Data Evaluation </span></strong>")
               ),
               p("Each of these stages must strictly adhere to the instructions in the sidebar, which will include steps 1-3 depending on the complexity of each stage."),
               
               p("We also offered the option of deploying R-code for R-markdown of the whole kidney sample type determination for transplant success, as well as feedback on this sample analysing application.   ")
               # Add content to the sidebar here
             ),
             mainPanel(
               tags$iframe(src = "https://docs.google.com/presentation/d/1_541wTZqu_C79XzMGA9IzP5vmB9xe9Oi/preview?rm=minimal&start=false",
                           style = "width:100%; height:800px;",
                           frameborder = "0", marginheight = "0", marginwidth = "0")
            )
           ) 
  ),
  
  # Data Collection Tab
  tabPanel("Data Collection",
           sidebarLayout(
             sidebarPanel(
               style = "background-color: #e6f0ff;", # Specify a lighter shade of blue using the hexadecimal color code
               
               p("Data collection is the first stage of early analysis involves three steps: gathering data, measuring it, and understanding the challenges so that medical researchers can concentrate on a specific objective and respond to research questions."),
               h3(
                 HTML("<strong><span style='font-size: 16px; background-color: yellow;'>Step 1: Gathering Information about dataset</span></strong>")
               ),
               p("In this step, we will brieftly evaluate the names of the columns in each sample type dataset, along with the row values, to see if they can actually address our research question.
We have already uploaded the GSE 34437 (Biopsy) and GSE 15296 (Blood) dataset files for you. You can choose from the sample types in the drop-down menus below based on your interests.  "),
               selectInput("data", "Choose a dataset:", choices = c("Blood", "Biopsy")),
               p("Use the Slider options to adjust the parameters for the number of gene expression ID values in the table for each dataset of sample types"),
               sliderInput("rows", "Number of Gene Expression ID:", min = 1, max = 100, value = 1),
               p(""),
               p("NOTE: The columns hyb_protocol and scan_protocol are empty due to the text length exceeds the limit; run the dataset directly (Code: #Data collection section in Shiny to R-Markdown tab) to see more information for these columns."),
               p(""),
               h3(
                 HTML("<strong><span style='font-size: 16px; background-color:#b5dfcf;'>Step 2: Measuring information</span></strong>")
               ),
               p("In this step, we aim to measure the information corresponding to each selected sample type"),
               verbatimTextOutput("outcome_counts"),
               p("After evaluating the summary, we can assume, for example, that both datasets present feature data and that both rejection and stable outcomes are presented. You are free to examine any additional columns and row values that might be relevant to your research questions."),
               h3(
                 HTML("<strong><span style='font-size: 16px; background-color: pink;'>Step 3: Challenges</span></strong>")
               ),
               p("In this step, you basically have an idea of what columns you want to use for your analysis and the challenges that will arise when integrating these columns into the data evaluation stage. "),
               p("Our Challenges:"),
               textOutput("challenge_message")
               
               
             ),
             mainPanel(
               h3("Pheno Data"),
               
               style = 'padding-top: 10px; width: 65%; overflow-x: scroll; height: 1075px; overflow-y: scroll; border: 3px solid #5A5A5A;',
               tabsetPanel(
                 div(tabPanel("Table", tableOutput("table")), style = 'width: 5300px;'),
                 conditionalPanel(
                   condition = "input.show_plot == true",
                   tabPanel("Plot", plotOutput("plot"))
                 )
               ),
               tags$head(tags$style(type = "text/css", ".container-fluid { max-width: 12600px; /* or 950px */ }"))
             )
           )
  )
  
  ,
  
  # Data Cleaning Tab
  tabPanel("Data Cleaning",
           sidebarLayout(
             sidebarPanel(
               style = "background-color: #e6f0ff;", # Specify a lighter shade of blue using the hexadecimal color code
               
               p("Data cleaning is the second stage, requiring the medical researcher to go through and assess whether the raw dataset is sufficient or not before critically applying filters to standardise and duplicate to a clean version, which involves three steps: evaluating the raw feature data, deciding on the appropriate filters, and transforming to cleaned data. "),
               h3(
                 HTML("<strong><span style='font-size: 16px; background-color: yellow;'>Step 1: Evaluating Feature Data (RAW)</span></strong>")
               ),
               p("In this step, check for any missing or empty Gene symbols, IDs, or NA values in both raw feature data datasets.
You can choose from the sample types in the drop-down menus below based on your interests. 
"),
               selectInput("feature_data", "Choose a dataset:", choices = c("Blood", "Biopsy")),
               p("(Hint: Click Gene symbol or ID columns)
What do you see?  ID column should contain full values. 
  "),
               h3(
                 HTML("<strong><span style='font-size: 13px; background-color: white;'>
Step 1 Results: some rows have missing or empty values, but the ID column has full values, and we cannot see the Rejection and Stable outcome columns in the Raw Feature Data. </span></strong>")
               ),
               
               h3(
                 HTML("<strong><span style='font-size: 16px; background-color: #b5dfcf;'>Step 2: Filtering Options</span></strong>")
               ),
               p("In this second step, researchers have to filter and combine Samplename or geo_accession and Gene Expression ID in PhenoData with ID in FeatureData in order to match ID in order to integrate Gene Symbol and other information. Also, any NA or empty rows are found and removed is applied. Further, converting the rejection and stable results into comparable circumstances using matrix functions for PhenoData (see #Data Cleaning in the shiny to R-markdown tab). "),
               p(""),
               h3(
                 HTML("<strong><span style='font-size: 13px; background-color: white;'>
Filtering Options: Using the values in the ID columns, join PhenoData and FeatureData by converting the outcome column in Pheno Data to comparable variables using Iimma and the model. matrix. </span></strong>")
               ),
               p("NOTE: 
PhenoData: Look for Samplename or geo_accession and Gene Expression ID in the data collection stage table. 
Feature Data:  ID can be found in the first columns of this stage. 
"),
               conditionalPanel(
                 condition = "input.feature_data == 'Blood'",
                 h3(
                   HTML("<strong><span style='font-size: 16px; background-color: pink;'>Step 3: Transforming to Cleaned - Blood</span></strong>")
                 ),
                 p("The third step involves applying to raw featureData all the filtering options mentioned in step 2 that are linked by ID with phenodata and featureData. 
To convert unclean data to clean data, click the Apply Filter button below. "),
                 actionButton("clean_blood", "Apply Filters - Blood"),
                 p("To see if it has been fully filtered, inspect the clean version of the table below the original table. For example, the clean version reduced the number of entries from 54,675 to 22,189 - Blood")
               ),
               conditionalPanel(
                 condition = "input.feature_data == 'Biopsy'",  
                 h3(
                   HTML("<strong><span style='font-size: 16px; background-color: pink;'>Step 3: Transforming to Cleaned - Biopsy</span></strong>")
                 ),
                 p("The third step involves applying to raw featureData all the filtering options mentioned in step 2 that are linked by ID with phenodata and featureData. 
To convert unclean data to clean data, click the Apply Filter button below. "),
                 actionButton("clean_biopsy", "Apply Filters - Biopsy"),
                 p("To see if it has been fully filtered, inspect the clean version of the table below the Raw FeatureData table. For example, the clean version reduced the number of entries from 54,675 to 22,189 - Biopsy")
               )
             ),
             mainPanel(
               h3("Feature Data"),
               style = 'padding-top: 10px; width: 65%; overflow-x: scroll; height: 1050px; overflow-y: scroll; border: 3px solid #5A5A5A;',
               
               dataTableOutput("featureData_table"),
               h3("Cleaned & Combined Data"),
               dataTableOutput("featureData_table2")
             )
           )
  )
  ,
  
  # Data Wrangling Tab
  tabPanel("Data Wrangling",
           sidebarLayout(
             sidebarPanel(
               style = "background-color: #e6f0ff;", # Specify a lighter shade of blue using the hexadecimal color code
               
               p("The third stage, Data Wrangling, consists of a single step where the researcher can map data into a structural format for analysis. In other words, reduce the size of your sample in preparation for exploratory analysis and data evaluation for training and testing. 
"),
               h3(
                 HTML("<strong><span style='font-size: 16px; background-color: yellow;'>Step 1: Analyzing Top expressed genes</span></strong>")
               ),
               p("Recall: We numbered down the same size using the minimum significant gene from the previous stage of Data cleaning after combining PhenoData outcome columns with cleaned versions of both samples. "),
               p("In this step, we want to reduce the size of the gene expression sample in order to figure out whether blood samples or biopsy are more accurate at predicting kidney transplants. We showed you the top 300 genes with different expression levels."),
               p("Define the genes number parameter"),
               sliderInput("gene_range", "Select number of genes:", min = 1, max = 300, value = 50),
               p("Please take note that the size of gene expression depends on your research question and goal"),
               p("NOTE: To view the Top 300 differentially expressed genes table for both blood and biopsy samples, click Refresh Tables."),
               actionButton("refresh_button", "Refresh Tables")
             ),
             mainPanel(
               h3("Top 300 differentially expressed genes - Blood"),
               DT::dataTableOutput("blood_table"),
               p(""),
               h3("Top 300 differentially expressed genes - Biopsy"),
               DT::dataTableOutput("biopsy_table")
             )
           )
  ),
  
  # Exploratory Data Analysis Tab
  tabPanel("Exploratory Data Analysis",
           sidebarLayout(
             sidebarPanel(
               style = "background-color: #e6f0ff;", # Specify a lighter shade of blue using the hexadecimal color code
               
               p("Exploratory data analysis is a fourth stage that consists of one step: finding general patterns and evaluation statistical hypotheses with graphical displays and statistics summaries."),
               h3(
                 HTML("<strong><span style='font-size: 16px; background-color: yellow;'>Step 1: Finding General Patterns</span></strong>")
               ),
               p("The process involved incorporating log-transformation for different blood and biopsy sample types as well as examining the distribution and normalisation of the data. For coding steps for log transformations, see #Exploratory Data Analysis in Shiny to R-Markdown."),
               p("You can choose from the sample types in the drop-down menus below based on your interests."),
               h3(
                 HTML("<strong><span style='font-size: 13px; background-color: yellow;'>BOXPLOT</span></strong>")
               ),
               p("A log-transformed boxplot is a graphic representation of the data distribution after a logarithmic transformation, which helps normalise skewed or highly variable data and makes it simpler to understand and analyse."),
               p("Check #Exploratory Data Analysis in Shiny to R-Markdown tab for Log-transformed step"),
               selectInput("data_type", "Choose a dataset ",
                           choices = c("Blood", "Biopsy"),
                           selected = "Blood"),
               p("NOTE: The length of each gene expression ID box and the black line (Median) should remain equal or slightly different in order to visualise normal gene expression ID distributions. This suggested that the dataset was normalised. "),

               verbatimTextOutput("summary"),
               p("After reviewing the visualisation pattern from log-transformed boxplot. Then, We need to analyse the selected dataset's statistics summaries."),
               h3(
                 HTML("<strong><span style='font-size: 13px; background-color: white;'>
In this case for example, we can says that the medians of all gene expression ID in boxplot is considered relatively acceptable and not too differentiate from all other quantiles results for both blood and biopsy dataset.   </span></strong>")
               ),
               h3(
                 HTML("<strong><span style='font-size: 14px; background-color: yellow;'> QQPLOT</span></strong>")
               ),
               p("A QQ plot (Quantile-Quantile plot) compares the quantiles of the observed data to the quantiles of the theoretical distribution to determine whether the observed data fit the theoretical distribution, with a straight line indicating a good fit."),
               p("Check #Exploratory Data Analysis in Shiny to R-Markdown tab for lmFit and eBayes functions applied to QQPLOT "),
               selectInput("dataset", "Choose a dataset (QQPLOT)",
                           choices = c("Blood", "Biopsy"),
                           selected = "Blood"),
               p("Adjust the theoretical and sample quantiles to see how well the data points align with the straight line in different distribution parameters."),
               p("Theoretical quantiles are the expected values of the standard normal distribution that are used as a reference to compare with the observed values "),
               numericInput("x_filter", "Theoretical Quantiles:", value = -4),
               p("Sample quantiles are values calculated from a dataset that group the data into equal-sized groups so that the distribution can be evaluated and compared to theoretical quantiles."),
               numericInput("y_filter", "Sample Quantiles", value = -4),
               h3(
                 HTML("<strong><span style='font-size: 13px; background-color: white;'>
In this case, we visually examine the point pattern on QQ plots and propose that both the blood and biopsy datasets closely match the theoretical distribution, with only a few outlines deviating at the tails but not significantly. We can state that the points are thought to be well-fitting and normally distributed.   </span></strong>")
               ),             ),
             mainPanel(
               plotOutput("boxplot", width = "100%", height = "700px"),
               plotOutput("qqplot", width = "100%", height = "700px")
             )
           )
  )
  ,
  
  # Data Interpretation Tab 
  tabPanel("Data Evaluation",
           sidebarLayout(
             sidebarPanel(
               style = "background-color: #e6f0ff;", # Specify a lighter shade of blue using the hexadecimal color code
               p("The fifth and final stage of data analysis—data evaluation or interpretation—determines the final outcome of the research question that has been addressed in stages one through four of data collection, cleaning, wrangling, and EDA. It incorporates in-sample testing and estimations analysis of machine learning models, such as roc curve accuracy. Including out-of-sample testing for in and out-of-sample comparison. "),
               p("It includes one step in which we have to examine the ROC curve, the in-sample and out-of-sample mean accuracy, and the accuracy summaries to determine which sample types, blood or biopsy, are better for predicting kidney success."),
               p("NOTE: To understand what occurs in sample cross-validations and the SVM machine learning method, review #In-sample and #Out of Sample under Data Integration in the Shiny to R-Markdown tab. "),
               h3(
                 HTML("<strong><span style='font-size: 16px; background-color: yellow;'>Step 1: Evaluating Machine Learning Models</span></strong>")
               ),
               p("In this step, we will visually evaluate the roc curve as well as the in-sample and out-of-sample mean accuracy. Then, we'll take a look at the statistical summaries of these two machine-learning models."),
               h4(
                 HTML("<strong><span style='font-size: 14px; background-color: yellow;'>In sample: Receiver Operating Characteristic (ROC) Curve</span></strong>")
               ),
               p("The ROC (Receiver Operating Characteristic) curve plots the true positive rate against the false positive rate at various classification thresholds to represent the performance of a binary classifier."),
               # Add slider inputs for the ranges
               sliderInput("fprRange", "False Positive Rate Range", min = 0, max = 1, value = c(0, 1), step = 0.01),
               p("FPR (False Positive Rate) indicates the percentage of falsely classified negative instances relative to all actual negative instances."),
               sliderInput("tprRange", "True Positive Rate Range", min = 0, max = 1, value = c(0, 1), step = 0.01),
               p(" TPR (True Positive Rate) represents the percentage of positively classified instances out of all actually positive instances."),
               sliderInput("distanceRange", "Distance Range", min = 0, max = 1, value = c(0, 1), step = 0.01),
               p("Distance calculates the Euclidean distance between the ROC curve and the ideal point (TPR = 1, FPR = 0) to assess a classifier's overall performance."),
               p("Hint: Use Zoom, Pan and Orbital Rotation functions to view closest threshold point to the top left corner"),
               h3(
                 HTML("<strong><span style='font-size: 13px; background-color: white;'>
Following a review of the visual presentation in ROC curve 3D, the ROC curve results revealed that when compared to blood sample methods, biopsy sample methods have more threshold points that are closer to the top left corner. For blood and biopsy results, we also look at the area under the curve. The AUC for blood is 0.9934, which is slightly lower than the AUC for biopsy, which is 1. This demonstrated that the biopsy classification model outperformed the blood classification model in distinguishing between positive and negative samples.   </span></strong>")
               ),
               h4(
                 HTML("<strong><span style='font-size: 14px; background-color: yellow;'>In sample & Out sample: Mean Accuracy (%)</span></strong>")
               ),
               p("Mean accuracy is a percentage that represents the average correctness of a model's predictions."),
               p("In order to evaluate the model's performance on training data (in-sample) and unseen data (out-of-sample), mean accuracy calculations for both in-sample and out-of-sample SVM (Support Vector Machine) are performed. This allows us to determine the model's generalisation ability and potential overfitting."),
               sliderInput(
                 inputId = "accuracyRange",
                 label = "Mean Accuracy Range",
                 min = 0.5,
                 max = 1,
                 value = c(0.5, 1),
                 step = 0.05
               ),
               p("You can modify the mean accuracy parameters for both in-sample and out-of-sample mean accuracy using the slider options."),
               HTML("<strong><span style='font-size: 13px; background-color: white;'>
Following a review of the visual presentation in Mean accuracy, the biopsy model outperforms the blood model both within and outside of the sample. The in-sample is deemed invalid because both models have nearly perfect mean accuracy scores of close to 100%. Out of the sample, the mean accuracy for both models is 0.87-0.95, which is considered lower but still quite high. The mean accuracy percentage in the Biopsy sample did not drop significantly, indicating that the dataset was not underfitting or overfitting and that the outcome was not overly complex. Hence. In general, we conclude that the biopsy model is more accurate. </span></strong>")
             ), 
             mainPanel(
               h3(
                 HTML("<strong><span style='font-size: 16px; background-color: White;'>ROC CURVE (3-Dimensions)</span></strong>")
               ),
               p(""),
               div(style = "border: 1px solid black;",
                   plotlyOutput("rocPlot", width = "100%", height = "700px")
               ),
               p(""),
               HTML("<div style='height: 10px;'></div>"),  # Adjust the height (in pixels) as needed
               p(""),
               verbatimTextOutput("outputText"),
               p(""),
               HTML("<div style='height: 10px;'></div>"),  # Adjust the height (in pixels) as needed
               p(""),
               h3(
                 HTML("<strong><span style='font-size: 16px; background-color: White;'>Mean Accuracy (2-Dimionsions)</span></strong>")
               ),
               p(""),
               div(style = "border: 1px solid black;",
                   plotlyOutput("accuracyPlot", width = "100%", height = "700px")
               ),
               h3(
                 HTML("<strong><span style='font-size: 14px; background-color: White;'>Left Boxplot - In sample, Right Boxplot - Out of Sample</span></strong>")
               ),               
               HTML("<div style='height: 10px;'></div>")

             )
           )
  ),
  # all code
  tabPanel("Shiny to R-Markdown",
           sidebarLayout(
             sidebarPanel(
               style = "background-color: #e6f0ff;",
               p(""),
               h3(
                 HTML("<strong><span style='font-size: 16px; background-color: yellow;'>Optional: The goal of this page is to assist researchers in incorporating all stages of the data analysis tutorial into R-Markdown. We want you to put what you've learned in the shiny app tutorials into practice.</span></strong>")
               )
             ),
             mainPanel(
               p(""),
               p("R-Markdown code for all data analysis stages"),
               p(""),
               verbatimTextOutput("codeOutput")  # Display R code here

             )
           )
  ),
  # User abilities survey Tab
  tabPanel("Feedback",
           
           mainPanel(
             p(""),
             p(""),
             tags$iframe(src = "https://docs.google.com/forms/d/e/1FAIpQLSd9OeNKD0EmiGdsyxAxoKRqliVHk3zhYzqbF6lzLZt5175S5g/viewform?embedded=true",
                         width = "150%", height = "800", frameborder = "0", marginheight = "0", marginwidth = "0")
           )
  )
)  


# Define server
server <- function(input, output, session) {
  
  observeEvent(input$dataset, {
    if (input$dataset == "Blood") {
      data <- fakefit2$t
    } else {
      data <- fakefit3$t
    }
    output$qqplot <- renderPlot({
      qqnorm(data, xlim = c(input$x_filter, max(data)), ylim = c(input$y_filter, max(data)))
      abline(0, 1)
    })
  })
  # Perform necessary preprocessing and calculations based on the selected data type
  observeEvent(input$data_type, {
    data <- switch(input$data_type,
                   "Blood" = {
                     fvarLabels(Blood) <- make.names(fvarLabels(Blood))
                     ex <- exprs(Blood)
                     qx <- as.numeric(quantile(ex, c(0., 0.25, 0.5, 0.75, 0.99, 1.0), na.rm = TRUE))
                     LogC <- (qx[5] > 100) ||
                       (qx[6] - qx[1] > 50 && qx[2] > 0) ||
                       (qx[2] > 0 && qx[2] < 1 && qx[4] > 1 && qx[4] < 2)
                     if (LogC) {
                       ex[which(ex <= 0)] <- NaN
                       exprs(Blood) <- log2(ex)
                     }
                     exprs(Blood)
                   },
                   "Biopsy" = {
                     fvarLabels(Biopsy) <- make.names(fvarLabels(Biopsy))
                     ex2 <- exprs(Biopsy)
                     qx2 <- as.numeric(quantile(ex2, c(0., 0.25, 0.5, 0.75, 0.99, 1.0), na.rm = TRUE))
                     LogC2 <- (qx2[5] > 100) ||
                       (qx2[6] - qx2[1] > 50 && qx2[2] > 0) ||
                       (qx2[2] > 0 && qx2[2] < 1 && qx2[4] > 1 && qx2[4] < 2)
                     if (LogC2) {
                       ex2[which(ex2 <= 0)] <- NaN
                       exprs(Biopsy) <- log2(ex2)
                     }
                     exprs(Biopsy)
                   }
    )
    
    # Generate boxplot
    output$boxplot <- renderPlot({
      boxplot(data, outline = FALSE, main = input$data_type)
    })
    
    # Generate summary
    output$summary <- renderPrint({
      summary(melt(data)$value)
    })
  })
  # Get the selected dataset
  selected_data <- reactive({
    if (input$data == "Blood") {
      # Subset the Blood dataset and add Outcome column
      Blood_subset <- Blood
      eMat <- exprs(Blood_subset)
      Blood_subset$Outcome <- ifelse(grepl("AR", Blood_subset$title), "Rejection", "Stable")
      Blood_subset
    } else {
      # Subset the Biopsy dataset and add Outcome column
      Biopsy_subset <- Biopsy
      eMat2 <- exprs(Biopsy_subset)
      Biopsy_subset$Outcome <- ifelse(grepl("AR", Biopsy_subset$title), "Rejection", "Stable")
      Biopsy_subset
    }
  })
  
  output$table <- renderTable({
    data <- head(selected_data(), n = input$rows)
    
    # Empty the "hyp_protocol" and "scan_protocol" columns
    data$hyb_protocol <- ""
    data$scan_protocol <- ""
    
    data
  })
  # Filter feature data for Blood
  featureDatablood_filtered <- eventReactive(input$clean_blood, {
    designblood <- model.matrix(~Outcome, data = pData(Blood))
    fitblood <- lmFit(exprs(Blood), designblood)
    fitblood <- eBayes(fitblood)
    
    fit4blood <- topTable(fitblood, genelist = featureDatablood[, "Gene symbol"], n = Inf) |>
      rownames_to_column("row") |>
      filter(!is.na(ID)) |>
      filter(ID != "") |>
      group_by(ID) |>
      filter(P.Value == min(P.Value)) |>
      pull(row)
    
    gset4blood <- Blood[fit4blood]
    fData(gset4blood)
  })
  
  # Filter feature data for Biopsy
  featureDatabiopsy_filtered <- eventReactive(input$clean_biopsy, {
    designbiopsy <- model.matrix(~Outcome, data = pData(Biopsy))
    fitbiopsy <- lmFit(exprs(Biopsy), designbiopsy)
    fitbiopsy <- eBayes(fitbiopsy)
    
    fit4biopsy <- topTable(fitbiopsy, genelist = featureDatabiopsy[, "Gene symbol"], n = Inf) |>
      rownames_to_column("row") |>
      filter(!is.na(ID)) |>
      filter(ID != "") |>
      group_by(ID) |>
      filter(P.Value == min(P.Value)) |>
      pull(row)
    
    gset4biopsy <- Biopsy[fit4biopsy]
    fData(gset4biopsy)
  })
  
  output$featureData_table <- renderDataTable({
    if (input$feature_data == "Blood") {
      featureDatablood
    } else {
      featureDatabiopsy
    }
  })
  
  output$featureData_table2 <- renderDataTable({
    if (input$feature_data == "Blood") {
      featureDatablood_filtered()
    } else {
      featureDatabiopsy_filtered()
    }
  })
  observeEvent(input$refresh_button, {
    output$blood_table <- DT::renderDataTable({
      featureData4blood_clean <- fData(gset4blood)
      design4blood <- model.matrix(~Outcome, data = pData(gset4blood))
      fit4blood_clean <- lmFit(exprs(gset4blood), design4blood)
      fit4blood_clean <- eBayes(fit4blood_clean)
      
      top4blood <- topTable(fit4blood_clean, genelist = featureData4blood_clean[, "Gene symbol"], n = input$gene_range)
      
      cat("Blood Gene Summary:\n")
      cat("Number of top genes:", nrow(top4blood), "\n")
      
      DT::datatable(top4blood)
      })
    })
    
    output$biopsy_table <- DT::renderDataTable({
      featureData4biopsy_clean <- fData(gset4biopsy)
      design4biopsy_clean <- model.matrix(~Outcome, data = pData(gset4biopsy))
      fit4biopsy_clean <- lmFit(exprs(gset4biopsy), design4biopsy_clean)
      fit4biopsy_clean <- eBayes(fit4biopsy_clean)
      
      top4biopsy <- topTable(fit4biopsy_clean, genelist = featureData4biopsy_clean[, "Gene symbol"], n = input$gene_range)
      
      cat("Biopsy Gene Summary:\n")
      cat("Number of top genes:", nrow(top4biopsy), "\n")
      
      DT::datatable(top4biopsy)
  })
  
  # Biopsy
  svm_fit_gse1b <- svm(x = X_gse1b, y = as.factor(y_gse1b))
  predictions_gse1b <- svm_fit_gse1b$decision.values
  roc_gse1b <- roc(as.factor(y_gse1b), predictions_gse1b)
  
  # Blood
  svm_fit_gse4b <- svm(x = X_gse4b, y = as.factor(y_gse4b))
  predictions_gse4b <- svm_fit_gse4b$decision.values
  roc_gse4b <- roc(as.factor(y_gse4b), predictions_gse4b)
  
  # Calculate distances from top left corner
  roc_data <- data.frame(
    Method = c(rep("Blood", length(roc_gse4b$specificities)), rep("Biopsy", length(roc_gse1b$specificities))),
    TPR = c(roc_gse4b$sensitivities, roc_gse1b$sensitivities),
    FPR = c(1 - roc_gse4b$specificities, 1 - roc_gse1b$specificities)
  )
  
  roc_data$Distance <- sqrt((roc_data$TPR - 1)^2 + roc_data$FPR^2)
  
  # Recalculate ROC curve for biopsy method
  roc_gse1b <- roc(as.factor(y_gse1b), 1 - as.numeric(predictions_gse1b), direction = ">")
  auc_gse1b <- auc(roc_gse1b)
  
  roc_gse4b <- roc(as.factor(y_gse4b), as.numeric(predictions_gse4b), direction = ">")
  auc_gse1b <- auc(roc_gse1b)
  auc_gse4b <- auc(roc_gse4b)
  
  threshold_line <- data.frame(
    x = c(1, rev(roc_gse1b$specificities), 0),
    y = c(1, rev(roc_gse1b$sensitivities), 0)
  )
  
  closest_method <- roc_data$Method[which.min(roc_data$Distance)]
  
  # 3D ROC plot
  output$rocPlot <- renderPlotly({
    plot_ly(
      data = roc_data,
      x = ~FPR,
      y = ~TPR,
      z = ~Distance,
      color = ~Method,
      colors = c("blue", "red")
    ) %>%
      add_markers() %>%
      add_trace(
        data = threshold_line,
        type = "mesh3d",
        inherit = FALSE,
        color = I("lightblue"),
        opacity = 0.5
      ) %>%
      layout(
        scene = list(
          xaxis = list(title = "False Positive Rate", range = input$fprRange),
          yaxis = list(title = "True Positive Rate", range = input$tprRange),
          zaxis = list(title = "Distance", range = input$distanceRange),
          camera = list(
            eye = list(x = -1.25, y = -1.25, z = 1.25)
          )
        )
      )
  })
  # Display the output under the 3D plot
  output$outputText <- renderText({
    paste("Method with the closest threshold point to the top left corner:", closest_method, "\n",
          "AUC for Biopsy:", auc_gse1b, "\n",
          "AUC for Blood:", auc_gse4b)
  })
  output$accuracyPlot <- renderPlotly({
    # Out of Sample Plot
    plot_df_out <- data.frame(
      accuracy = c(cv_accuracy_gse1c, cv_accuracy_gse4c),
      model = c(rep("Biopsy", length(cv_accuracy_gse1c)), rep("Blood", length(cv_accuracy_gse4c)))
    )
    
    outsamp <- ggplot(data = plot_df_out, aes(x = model, y = accuracy)) +
      geom_boxplot(aes(fill = model)) +
      geom_jitter(aes(color = model), alpha = 0.3) +
      labs( x = "Sample Types", y = "Mean Accuracy (%)") +
      scale_color_manual(values = c("blue", "red")) +  # Set colors for Blood and Biopsy
      scale_fill_manual(values = c("blue", "red")) +  # Set colors for boxplot
      theme(plot.title = element_text(hjust = 0.5, size = 12), panel.border = element_rect(colour = "black", fill = NA, size = 1))
    
    outsamp_plotly <- ggplotly(outsamp)
    
    # In Sample Plot
    plot_df_in <- data.frame(
      accuracy = c(cv_accuracy_gse1b, cv_accuracy_gse4b),
      model = c(rep("Biopsy", length(cv_accuracy_gse1b)), rep("Blood", length(cv_accuracy_gse4b)))
    )
    
    insamp <- ggplot(data = plot_df_in, aes(x = model, y = accuracy)) +
      geom_boxplot(aes(fill = model)) +
      geom_jitter(aes(color = model), alpha = 0.3) +
      labs( x = "Sample Types", y = "Mean Accuracy (%)") +
      scale_color_manual(values = c("blue", "red")) +  # Set colors for Blood and Biopsy
      scale_fill_manual(values = c("blue", "red")) +  # Set colors for boxplot
      theme(plot.title = element_text(hjust = 0.5, size = 12), panel.border = element_rect(colour = "black", fill = NA, size = 1)) +
      coord_cartesian(ylim = input$accuracyRange)  # Apply y-axis range based on the slider input
    
    insamp_plotly <- ggplotly(insamp)
    
    # Create the subplot
    subplot(insamp_plotly, outsamp_plotly, shareX = TRUE, nrows = 1, heights = c(0.7))
  })
  output$bloodout1 <- renderPlotly({
    blood_plot <- plot_ly(pca_df, x = ~PC1, y = ~PC2, color = ~y_gse4c, colors = colors, type = "scatter", mode = "markers",
                          marker = list(size = 10, opacity = 0.7)) %>%
      add_trace(data = grid, x = ~PC1, y = ~PC2, color = ~predictions, colors = colors, type = "scatter", mode = "markers",
                marker = list(size = 3, opacity = 0.8))
    
    blood_plot <- layout(blood_plot, title = "SVM Decision Boundary with a maximum margin (Blood)",
                         xaxis = list(title = "PC1"), yaxis = list(title = "PC2"))
    
    blood_plot
  })
  
  output$biopsyout1 <- renderPlotly({
    biopsy_plot <- plot_ly(pca_df1, x = ~PC1b, y = ~PC2b, color = ~y_gse1c, colors = colors, type = "scatter", mode = "markers",
                           marker = list(size = 10, opacity = 0.7)) %>%
      add_trace(data = grid1, x = ~PC1b, y = ~PC2b, color = ~predictions1, colors = colors, type = "scatter", mode = "markers",
                marker = list(size = 3, opacity = 0.8))
    
    biopsy_plot <- layout(biopsy_plot, title = "SVM Decision Boundary with a maximum margin (Biopsy)",
                          xaxis = list(title = "PC1b"), yaxis = list(title = "PC2b"))
    
    biopsy_plot
  })
  code <- readLines("C:/Users/Lenovo Ideapad/Downloads/Q1.Rmd")
  
  output$codeOutput <- renderPrint({
    cat(code, sep = "\n")
  })
  output$Blood_collection <- renderPrint({
    show(Blood)
  })
  output$Biopsy_collection <- renderPrint({
    show(Biopsy)

  })
  output$plot <- renderPlot({
    if (input$data == "Blood") {
      plot(iris$Sepal.Length, iris$Sepal.Width)
    } else {
      plot(mtcars$mpg, mtcars$wt)
    }
  })
  
  output$outcome_counts <- renderPrint({
    data <- selected_data()
    rejection_count <- sum(data$Outcome == "Rejection")
    stable_count <- sum(data$Outcome == "Stable")
    total_rows <- nrow(data)
    total_samples <- rejection_count + stable_count
    
    
    cat("Total features:", total_rows, "\n")
    cat("Total samples:", total_samples, "\n")
    
    cat("Rejection count:", rejection_count, "\n")
    cat("Stable count:", stable_count, "\n")
    
    output$challenge_message <- renderText({
      data <- selected_data()
      rejection_count <- sum(data$Outcome == "Rejection")
      stable_count <- sum(data$Outcome == "Stable")
      
      if (rejection_count != stable_count) {
        count_message <- if (rejection_count > stable_count) {
          paste("Rejection count (",rejection_count,") is higher than Stable count (", stable_count, ").", sep = "")
        } else {
          paste("Stable count (",stable_count,") is higher than Rejection count (", rejection_count, ").", sep = "")
        }
        original_message <- "Rejection and stable outcomes from this dataset are not equal. To check for normalisation in these unequal outcomes, we will need to go through cleaning, wrangling, and Exploratory Data Analysis. Next, proceed to the Data Cleaning stage"
        paste(count_message, original_message)
      } else {
        ""
      }
    })
    
    
  })
  
}
shinyApp(ui, server)

